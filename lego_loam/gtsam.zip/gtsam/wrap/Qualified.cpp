#include <wrap/Qualified.h>

namespace wrap {
  std::vector<Qualified>  Qualified::BasicTypedefs;
}
